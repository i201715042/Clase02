//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, Mundo"

var myAge = 21
myAge += 22

let implicitInteger = 2

//Ejercicio 01
//Declata una constante de tipo float, de manera explicita cuyo valor sea4

let myFloat :Float = 4

let myName = "Josue"

let greetings = "My name is" + myName

let myAgesIs = "My age is " + String(myAge)

//clase 02

let oranges = 5
let apples = 3
let arangesSumary = " Tengo \(oranges) naranjas "
let applesSumary = " Tengo \(apples) manzanas "
let fruitsSumary = " Tengo \(oranges + apples) frutas "
//lo que esta adentro lo convierte a cadena
let ageSumary = " Mi edad es \(myAge)"

//Arreglos

var notas: [Int ]
//inicialize mi arreglo pero sin elementos,asiganamos espacio en memoria
notas = [Int]()

notas.append(16)
notas.append(20)
notas.append(18)

for  i  in notas{
    print (i)
}

//sacar elementos ; i va tomando las posiciones de cada uno de las notas
// notas.remove(at: 0)

// Diccionario -> pares de valores
var person :[String :Any]

person = ["name":"Jorge",
          "age":34,
          "dni": "46229159"]
//cambio de valor
//switfplayground
//switf tour
person["age"] = 35

print(person["age"]!)


